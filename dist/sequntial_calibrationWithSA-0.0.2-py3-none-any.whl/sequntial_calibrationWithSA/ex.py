def exPrint(msg):
    print(msg + "asd")