from ex import *

print("hello!")